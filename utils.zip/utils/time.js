// utils/time.js
export function nowUtcIso() {
    return new Date().toISOString();
}